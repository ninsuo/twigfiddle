``random``
==========

.. versionadded:: 1.5
    The random function was added in Twig 1.5.

The ``random`` function returns a random item from a sequence:

.. code-block:: jinja

    {{ random(['apple', 'orange', 'citrus']) }}
