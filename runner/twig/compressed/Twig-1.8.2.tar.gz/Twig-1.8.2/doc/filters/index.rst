Filters
=======

.. toctree::
    :maxdepth: 1

    date
    format
    replace
    number_format
    url_encode
    json_encode
    convert_encoding
    title
    capitalize
    nl2br
    upper
    lower
    striptags
    join
    reverse
    length
    sort
    default
    keys
    escape
    raw
    merge
    slice
    trim
