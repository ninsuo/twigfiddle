``none``
========

``none`` returns ``true`` if the variable is ``none``:

.. code-block:: jinja

    {{ var is none }}
