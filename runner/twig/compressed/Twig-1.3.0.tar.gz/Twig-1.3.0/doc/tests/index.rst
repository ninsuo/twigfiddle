Tests
=====

.. toctree::
    :maxdepth: 1

    divisibleby
    none
    even
    odd
    sameas
    constant
    defined
    empty
