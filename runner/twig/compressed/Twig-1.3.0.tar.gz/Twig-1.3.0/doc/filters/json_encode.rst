``json_encode``
===============

The ``json_encode`` filter returns the JSON representation of a string:

.. code-block:: jinja

    {{ data|json_encode() }}
