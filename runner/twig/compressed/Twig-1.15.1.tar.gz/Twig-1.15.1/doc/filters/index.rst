Filters
=======

.. toctree::
    :maxdepth: 1

    abs
    batch
    capitalize
    convert_encoding
    date
    date_modify
    default
    escape
    first
    format
    join
    json_encode
    keys
    last
    length
    lower
    nl2br
    number_format
    merge
    upper
    raw
    replace
    reverse
    round
    slice
    sort
    split
    striptags
    title
    trim
    url_encode
