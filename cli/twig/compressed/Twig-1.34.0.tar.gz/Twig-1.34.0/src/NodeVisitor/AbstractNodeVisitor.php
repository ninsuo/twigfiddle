<?php

namespace Twig\NodeVisitor;

require __DIR__.'/../../lib/Twig/BaseNodeVisitor.php';

if (\false) {
    class AbstractNodeVisitor extends \Twig_BaseNodeVisitor
    {
    }
}
