<?php

namespace Twig\NodeVisitor;

require __DIR__.'/../../lib/Twig/NodeVisitor/Optimizer.php';

if (\false) {
    class OptimizerNodeVisitor extends \Twig_NodeVisitor_Optimizer
    {
    }
}
