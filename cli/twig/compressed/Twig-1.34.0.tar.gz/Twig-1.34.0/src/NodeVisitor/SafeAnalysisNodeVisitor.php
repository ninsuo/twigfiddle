<?php

namespace Twig\NodeVisitor;

require __DIR__.'/../../lib/Twig/NodeVisitor/SafeAnalysis.php';

if (\false) {
    class SafeAnalysisNodeVisitor extends \Twig_NodeVisitor_SafeAnalysis
    {
    }
}
