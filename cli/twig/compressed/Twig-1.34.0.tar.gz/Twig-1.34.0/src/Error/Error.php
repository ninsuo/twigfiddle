<?php

namespace Twig\Error;

require __DIR__.'/../../lib/Twig/Error.php';

if (\false) {
    class Error extends \Twig_Error
    {
    }
}
