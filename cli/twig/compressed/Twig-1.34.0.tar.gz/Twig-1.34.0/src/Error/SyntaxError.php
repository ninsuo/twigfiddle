<?php

namespace Twig\Error;

require __DIR__.'/../../lib/Twig/Error/Syntax.php';

if (\false) {
    class SyntaxError extends \Twig_Error_Syntax
    {
    }
}
