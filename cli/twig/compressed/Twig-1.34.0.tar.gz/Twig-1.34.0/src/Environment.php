<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Environment.php';

if (\false) {
    class Environment extends \Twig_Environment
    {
    }
}
