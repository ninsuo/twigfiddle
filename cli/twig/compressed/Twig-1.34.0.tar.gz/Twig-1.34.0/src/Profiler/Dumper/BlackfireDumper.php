<?php

namespace Twig\Profiler\Dumper;

require __DIR__.'/../../../lib/Twig/Profiler/Dumper/Blackfire.php';

if (\false) {
    class BlackfireDumper extends \Twig_Profiler_Dumper_Blackfire
    {
    }
}
