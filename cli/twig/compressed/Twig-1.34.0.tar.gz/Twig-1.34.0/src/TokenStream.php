<?php

namespace Twig;

require __DIR__.'/../lib/Twig/TokenStream.php';

if (\false) {
    class TokenStream extends \Twig_TokenStream
    {
    }
}
