<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Token.php';

if (\false) {
    class Token extends \Twig_Token
    {
    }
}
