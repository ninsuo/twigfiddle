<?php

namespace Twig\Cache;

require __DIR__.'/../../lib/Twig/Cache/Filesystem.php';

if (\false) {
    class FilesystemCache extends \Twig_Cache_Filesystem
    {
    }
}
