<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/Optimizer.php';

if (\false) {
    class OptimizerExtension extends \Twig_Extension_Optimizer
    {
    }
}
