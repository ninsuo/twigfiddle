<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/Core.php';

if (\false) {
    class CoreExtension extends \Twig_Extension_Core
    {
    }
}
