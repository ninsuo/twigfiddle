<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Div.php';

if (\false) {
    class DivBinary extends \Twig_Node_Expression_Binary_Div
    {
    }
}
