<?php

namespace Twig\Node\Expression\Test;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Test/Even.php';

if (\false) {
    class EvenTest extends \Twig_Node_Expression_Test_Even
    {
    }
}
