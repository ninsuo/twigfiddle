<?php

namespace Twig\Node\Expression\Test;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Test/Constant.php';

if (\false) {
    class ConstantTest extends \Twig_Node_Expression_Test_Constant
    {
    }
}
