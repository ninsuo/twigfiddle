<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/In.php';

if (\false) {
    class InBinary extends \Twig_Node_Expression_Binary_In
    {
    }
}
