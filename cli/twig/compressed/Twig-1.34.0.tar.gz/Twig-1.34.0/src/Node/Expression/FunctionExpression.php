<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Function.php';

if (\false) {
    class FunctionExpression extends \Twig_Node_Expression_Function
    {
    }
}
