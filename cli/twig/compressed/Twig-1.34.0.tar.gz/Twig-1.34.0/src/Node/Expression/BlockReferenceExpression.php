<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/BlockReference.php';

if (\false) {
    class BlockReferenceExpression extends \Twig_Node_Expression_BlockReference
    {
    }
}
