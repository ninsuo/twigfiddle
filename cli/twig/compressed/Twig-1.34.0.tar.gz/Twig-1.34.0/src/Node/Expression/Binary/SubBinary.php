<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Sub.php';

if (\false) {
    class SubBinary extends \Twig_Node_Expression_Binary_Sub
    {
    }
}
