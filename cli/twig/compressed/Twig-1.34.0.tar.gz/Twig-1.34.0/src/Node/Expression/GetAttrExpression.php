<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/GetAttr.php';

if (\false) {
    class GetAttrExpression extends \Twig_Node_Expression_GetAttr
    {
    }
}
