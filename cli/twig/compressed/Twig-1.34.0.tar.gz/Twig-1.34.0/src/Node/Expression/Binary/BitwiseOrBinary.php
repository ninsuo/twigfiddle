<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/BitwiseOr.php';

if (\false) {
    class BitwiseOrBinary extends \Twig_Node_Expression_Binary_BitwiseOr
    {
    }
}
