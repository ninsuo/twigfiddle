<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/And.php';

if (\false) {
    class AndBinary extends \Twig_Node_Expression_Binary_And
    {
    }
}
