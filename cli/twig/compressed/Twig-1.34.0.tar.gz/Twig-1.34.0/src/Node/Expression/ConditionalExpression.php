<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Conditional.php';

if (\false) {
    class ConditionalExpression extends \Twig_Node_Expression_Conditional
    {
    }
}
