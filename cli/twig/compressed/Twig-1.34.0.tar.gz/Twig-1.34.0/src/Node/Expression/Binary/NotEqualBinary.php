<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/NotEqual.php';

if (\false) {
    class NotEqualBinary extends \Twig_Node_Expression_Binary_NotEqual
    {
    }
}
