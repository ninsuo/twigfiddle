<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression.php';

if (\false) {
    class AbstractExpression extends \Twig_Node_Expression
    {
    }
}
