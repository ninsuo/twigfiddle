<?php

namespace Twig\Node\Expression\Test;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Test/Defined.php';

if (\false) {
    class DefinedTest extends \Twig_Node_Expression_Test_Defined
    {
    }
}
