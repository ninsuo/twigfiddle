<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Mul.php';

if (\false) {
    class MulBinary extends \Twig_Node_Expression_Binary_Mul
    {
    }
}
