<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Or.php';

if (\false) {
    class OrBinary extends \Twig_Node_Expression_Binary_Or
    {
    }
}
