<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/NullCoalesce.php';

if (\false) {
    class NullCoalesceExpression extends \Twig_Node_Expression_NullCoalesce
    {
    }
}
