<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/AssignName.php';

if (\false) {
    class AssignNameExpression extends \Twig_Node_Expression_AssignName
    {
    }
}
