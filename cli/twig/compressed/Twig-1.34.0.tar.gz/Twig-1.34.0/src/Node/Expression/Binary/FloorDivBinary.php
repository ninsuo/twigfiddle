<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/FloorDiv.php';

if (\false) {
    class FloorDivBinary extends \Twig_Node_Expression_Binary_FloorDiv
    {
    }
}
