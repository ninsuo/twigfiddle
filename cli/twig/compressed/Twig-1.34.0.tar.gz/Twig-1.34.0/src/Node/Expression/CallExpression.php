<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Call.php';

if (\false) {
    class CallExpression extends \Twig_Node_Expression_Call
    {
    }
}
