<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/NodeOutputInterface.php';

if (\false) {
    interface NodeOutputInterface extends \Twig_NodeOutputInterface
    {
    }
}
