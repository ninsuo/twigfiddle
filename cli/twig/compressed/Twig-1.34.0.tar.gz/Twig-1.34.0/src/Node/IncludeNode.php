<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Include.php';

if (\false) {
    class IncludeNode extends \Twig_Node_Include
    {
    }
}
