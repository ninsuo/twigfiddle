<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node.php';

if (\false) {
    class Node extends \Twig_Node
    {
    }
}
