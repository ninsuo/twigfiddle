<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Do.php';

if (\false) {
    class DoNode extends \Twig_Node_Do
    {
    }
}
