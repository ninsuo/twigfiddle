<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Embed.php';

if (\false) {
    class EmbedNode extends \Twig_Node_Embed
    {
    }
}
