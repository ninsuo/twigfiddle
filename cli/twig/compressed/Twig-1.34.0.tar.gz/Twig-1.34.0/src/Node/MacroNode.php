<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Macro.php';

if (\false) {
    class MacroNode extends \Twig_Node_Macro
    {
    }
}
