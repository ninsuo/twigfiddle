<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Import.php';

if (\false) {
    class ImportNode extends \Twig_Node_Import
    {
    }
}
