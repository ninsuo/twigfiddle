<?php

namespace Twig\Util;

require __DIR__.'/../../lib/Twig/Util/DeprecationCollector.php';

if (\false) {
    class DeprecationCollector extends \Twig_Util_DeprecationCollector
    {
    }
}
