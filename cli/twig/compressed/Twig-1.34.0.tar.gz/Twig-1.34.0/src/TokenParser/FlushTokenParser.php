<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Flush.php';

if (\false) {
    class FlushTokenParser extends \Twig_TokenParser_Flush
    {
    }
}
