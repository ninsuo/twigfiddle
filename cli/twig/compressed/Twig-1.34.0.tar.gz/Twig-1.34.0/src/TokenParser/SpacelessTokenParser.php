<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Spaceless.php';

if (\false) {
    class SpacelessTokenParser extends \Twig_TokenParser_Spaceless
    {
    }
}
