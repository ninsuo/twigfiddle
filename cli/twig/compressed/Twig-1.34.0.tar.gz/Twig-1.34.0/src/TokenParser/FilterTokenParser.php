<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Filter.php';

if (\false) {
    class FilterTokenParser extends \Twig_TokenParser_Filter
    {
    }
}
