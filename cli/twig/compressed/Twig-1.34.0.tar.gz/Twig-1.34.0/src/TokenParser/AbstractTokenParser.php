<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser.php';

if (\false) {
    class AbstractTokenParser extends \Twig_TokenParser
    {
    }
}
