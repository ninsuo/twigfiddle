``lower``
=========

The ``lower`` filter converts a value to lowercase:

.. code-block:: jinja

    {{ 'WELCOME'|lower }}

    {# outputs 'welcome' #}
