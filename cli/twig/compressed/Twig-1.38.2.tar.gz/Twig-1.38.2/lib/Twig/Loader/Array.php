<?php

use Twig\Loader\ArrayLoader;

class_exists('Twig\Loader\ArrayLoader');

if (\false) {
    class Twig_Loader_Array extends ArrayLoader
    {
    }
}
