<?php

use Twig\Loader\ChainLoader;

class_exists('Twig\Loader\ChainLoader');

if (\false) {
    class Twig_Loader_Chain extends ChainLoader
    {
    }
}
