<?php

use Twig\Node\Expression\Filter\DefaultFilter;

class_exists('Twig\Node\Expression\Filter\DefaultFilter');

if (\false) {
    class Twig_Node_Expression_Filter_Default extends DefaultFilter
    {
    }
}
