<?php

namespace Twig;

require __DIR__.'/../lib/Twig/SimpleTest.php';

if (\false) {
    class TwigTest extends \Twig_SimpleTest
    {
    }
}
