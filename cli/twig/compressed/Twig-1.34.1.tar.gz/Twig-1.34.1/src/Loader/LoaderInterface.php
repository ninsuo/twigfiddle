<?php

namespace Twig\Loader;

require __DIR__.'/../../lib/Twig/LoaderInterface.php';

if (\false) {
    interface LoaderInterface extends \Twig_LoaderInterface
    {
    }
}
