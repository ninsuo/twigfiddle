<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Include.php';

if (\false) {
    class IncludeTokenParser extends \Twig_TokenParser_Include
    {
    }
}
