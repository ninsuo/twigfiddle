<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Do.php';

if (\false) {
    class DoTokenParser extends \Twig_TokenParser_Do
    {
    }
}
