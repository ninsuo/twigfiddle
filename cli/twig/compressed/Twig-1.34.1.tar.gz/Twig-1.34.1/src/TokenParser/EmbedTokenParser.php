<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Embed.php';

if (\false) {
    class EmbedTokenParser extends \Twig_TokenParser_Embed
    {
    }
}
