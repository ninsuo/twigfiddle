<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Sandbox.php';

if (\false) {
    class SandboxTokenParser extends \Twig_TokenParser_Sandbox
    {
    }
}
