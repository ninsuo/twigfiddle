<?php

namespace Twig;

require __DIR__.'/../lib/Twig/NodeTraverser.php';

if (\false) {
    class NodeTraverser extends \Twig_NodeTraverser
    {
    }
}
