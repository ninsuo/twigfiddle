<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/With.php';

if (\false) {
    class WithNode extends \Twig_Node_With
    {
    }
}
