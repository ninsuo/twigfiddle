<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/ForLoop.php';

if (\false) {
    class ForLoopNode extends \Twig_Node_ForLoop
    {
    }
}
