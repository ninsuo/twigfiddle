<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Print.php';

if (\false) {
    class PrintNode extends \Twig_Node_Print
    {
    }
}
