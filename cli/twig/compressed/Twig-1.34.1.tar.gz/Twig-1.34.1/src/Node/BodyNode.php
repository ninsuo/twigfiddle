<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Body.php';

if (\false) {
    class BodyNode extends \Twig_Node_Body
    {
    }
}
