<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/NodeCaptureInterface.php';

if (\false) {
    interface NodeCaptureInterface extends \Twig_NodeCaptureInterface
    {
    }
}
