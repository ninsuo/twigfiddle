<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Block.php';

if (\false) {
    class BlockNode extends \Twig_Node_Block
    {
    }
}
