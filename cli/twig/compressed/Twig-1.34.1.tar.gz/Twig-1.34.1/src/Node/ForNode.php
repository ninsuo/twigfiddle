<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/For.php';

if (\false) {
    class ForNode extends \Twig_Node_For
    {
    }
}
