<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/If.php';

if (\false) {
    class IfNode extends \Twig_Node_If
    {
    }
}
