<?php

namespace Twig\Node\Expression\Unary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Unary/Neg.php';

if (\false) {
    class NegUnary extends \Twig_Node_Expression_Unary_Neg
    {
    }
}
