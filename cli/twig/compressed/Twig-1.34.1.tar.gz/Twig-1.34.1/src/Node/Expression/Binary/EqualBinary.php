<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Equal.php';

if (\false) {
    class EqualBinary extends \Twig_Node_Expression_Binary_Equal
    {
    }
}
