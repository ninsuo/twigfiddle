<?php

namespace Twig\Node\Expression\Test;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Test/Odd.php';

if (\false) {
    class OddTest extends \Twig_Node_Expression_Test_Odd
    {
    }
}
