<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Filter.php';

if (\false) {
    class FilterExpression extends \Twig_Node_Expression_Filter
    {
    }
}
