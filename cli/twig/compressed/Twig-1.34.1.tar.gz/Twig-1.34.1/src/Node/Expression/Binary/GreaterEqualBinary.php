<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/GreaterEqual.php';

if (\false) {
    class GreaterEqualBinary extends \Twig_Node_Expression_Binary_GreaterEqual
    {
    }
}
