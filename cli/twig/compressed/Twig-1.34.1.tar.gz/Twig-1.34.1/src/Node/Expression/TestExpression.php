<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Test.php';

if (\false) {
    class TestExpression extends \Twig_Node_Expression_Test
    {
    }
}
