<?php

namespace Twig\Node\Expression\Unary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Unary.php';

if (\false) {
    class AbstractUnary extends \Twig_Node_Expression_Unary
    {
    }
}
