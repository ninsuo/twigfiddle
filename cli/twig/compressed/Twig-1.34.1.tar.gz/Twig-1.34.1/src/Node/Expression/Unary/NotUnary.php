<?php

namespace Twig\Node\Expression\Unary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Unary/Not.php';

if (\false) {
    class NotUnary extends \Twig_Node_Expression_Unary_Not
    {
    }
}
