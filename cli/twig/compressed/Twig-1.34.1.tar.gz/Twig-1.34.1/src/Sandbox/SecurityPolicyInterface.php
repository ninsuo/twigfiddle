<?php

namespace Twig\Sandbox;

require __DIR__.'/../../lib/Twig/Sandbox/SecurityPolicyInterface.php';

if (\false) {
    interface SecurityPolicyInterface extends \Twig_Sandbox_SecurityPolicyInterface
    {
    }
}
