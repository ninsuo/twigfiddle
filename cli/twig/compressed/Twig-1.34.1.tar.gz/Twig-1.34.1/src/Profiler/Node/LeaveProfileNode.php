<?php

namespace Twig\Profiler\Node;

require __DIR__.'/../../../lib/Twig/Profiler/Node/LeaveProfile.php';

if (\false) {
    class LeaveProfileNode extends \Twig_Profiler_Node_LeaveProfile
    {
    }
}
