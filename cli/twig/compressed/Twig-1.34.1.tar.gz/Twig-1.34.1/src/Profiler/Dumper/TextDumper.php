<?php

namespace Twig\Profiler\Dumper;

require __DIR__.'/../../../lib/Twig/Profiler/Dumper/Text.php';

if (\false) {
    class TextDumper extends \Twig_Profiler_Dumper_Text
    {
    }
}
