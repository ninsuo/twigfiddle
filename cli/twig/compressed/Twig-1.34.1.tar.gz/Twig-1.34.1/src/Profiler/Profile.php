<?php

namespace Twig\Profiler;

require __DIR__.'/../../lib/Twig/Profiler/Profile.php';

if (\false) {
    class Profile extends \Twig_Profiler_Profile
    {
    }
}
