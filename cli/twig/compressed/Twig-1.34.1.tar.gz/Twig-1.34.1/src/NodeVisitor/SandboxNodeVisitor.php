<?php

namespace Twig\NodeVisitor;

require __DIR__.'/../../lib/Twig/NodeVisitor/Sandbox.php';

if (\false) {
    class SandboxNodeVisitor extends \Twig_NodeVisitor_Sandbox
    {
    }
}
