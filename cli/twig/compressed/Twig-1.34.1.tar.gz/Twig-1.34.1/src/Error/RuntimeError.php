<?php

namespace Twig\Error;

require __DIR__.'/../../lib/Twig/Error/Runtime.php';

if (\false) {
    class RuntimeError extends \Twig_Error_Runtime
    {
    }
}
