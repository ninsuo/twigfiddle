<?php

namespace Twig\Util;

require __DIR__.'/../../lib/Twig/Util/TemplateDirIterator.php';

if (\false) {
    class TemplateDirIterator extends \Twig_Util_TemplateDirIterator
    {
    }
}
