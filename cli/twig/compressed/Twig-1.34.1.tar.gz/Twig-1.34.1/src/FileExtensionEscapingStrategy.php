<?php

namespace Twig;

require __DIR__.'/../lib/Twig/FileExtensionEscapingStrategy.php';

if (\false) {
    class FileExtensionEscapingStrategy extends \Twig_FileExtensionEscapingStrategy
    {
    }
}
