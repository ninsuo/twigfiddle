<?php

namespace Twig;

require __DIR__.'/../lib/Twig/SimpleFilter.php';

if (\false) {
    class TwigFilter extends \Twig_SimpleFilter
    {
    }
}
