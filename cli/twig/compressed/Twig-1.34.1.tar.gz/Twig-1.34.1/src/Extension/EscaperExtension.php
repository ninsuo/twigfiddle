<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/Escaper.php';

if (\false) {
    class EscaperExtension extends \Twig_Extension_Escaper
    {
    }
}
