<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/GlobalsInterface.php';

if (\false) {
    interface GlobalsInterface extends \Twig_Extension_ExtensionInterface
    {
    }
}
