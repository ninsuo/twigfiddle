<?php

use Twig\Node\Expression\Binary\ModBinary;

class_exists('Twig\Node\Expression\Binary\ModBinary');

if (\false) {
    class Twig_Node_Expression_Binary_Mod extends ModBinary
    {
    }
}
