<?php

namespace Twig;

class_exists('Twig_ExpressionParser');

if (\false) {
    class ExpressionParser extends \Twig_ExpressionParser
    {
    }
}
