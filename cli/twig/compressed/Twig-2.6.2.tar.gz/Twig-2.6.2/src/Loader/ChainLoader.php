<?php

namespace Twig\Loader;

class_exists('Twig_Loader_Chain');

if (\false) {
    class ChainLoader extends \Twig_Loader_Chain
    {
    }
}
