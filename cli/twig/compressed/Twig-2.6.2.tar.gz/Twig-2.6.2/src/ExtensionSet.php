<?php

namespace Twig;

class_exists('Twig_ExtensionSet');

if (\false) {
    class ExtensionSet extends \Twig_ExtensionSet
    {
    }
}
