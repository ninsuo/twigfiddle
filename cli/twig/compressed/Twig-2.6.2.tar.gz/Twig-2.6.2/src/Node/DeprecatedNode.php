<?php

namespace Twig\Node;

class_exists('Twig_Node_Deprecated');

if (\false) {
    class DeprecatedNode extends \Twig_Node_Deprecated
    {
    }
}
