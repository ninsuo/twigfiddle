<?php

namespace Twig;

class_exists('Twig_Template');

if (\false) {
    class Template extends \Twig_Template
    {
    }
}
