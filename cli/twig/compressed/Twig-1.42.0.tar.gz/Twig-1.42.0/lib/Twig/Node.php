<?php

use Twig\Node\Node;

class_exists('Twig\Node\Node');

if (\false) {
    class Twig_Node extends Node
    {
    }
}
