<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Parser.php';

if (\false) {
    class Parser extends \Twig_Parser
    {
    }
}
