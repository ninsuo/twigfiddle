<?php

namespace Twig\RuntimeLoader;

require __DIR__.'/../../lib/Twig/FactoryRuntimeLoader.php';

if (\false) {
    class FactoryRuntimeLoader extends \Twig_FactoryRuntimeLoader
    {
    }
}
