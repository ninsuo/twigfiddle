<?php

namespace Twig;

require __DIR__.'/../lib/Twig/SimpleFunction.php';

if (\false) {
    class TwigFunction extends \Twig_SimpleFunction
    {
    }
}
