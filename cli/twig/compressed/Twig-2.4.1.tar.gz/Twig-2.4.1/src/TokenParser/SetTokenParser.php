<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Set.php';

if (\false) {
    class SetTokenParser extends \Twig_TokenParser_Set
    {
    }
}
