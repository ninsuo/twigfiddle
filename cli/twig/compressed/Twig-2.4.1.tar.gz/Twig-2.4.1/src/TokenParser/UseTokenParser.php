<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Use.php';

if (\false) {
    class UseTokenParser extends \Twig_TokenParser_Use
    {
    }
}
