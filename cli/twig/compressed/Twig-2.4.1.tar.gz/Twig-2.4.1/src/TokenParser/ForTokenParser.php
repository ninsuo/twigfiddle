<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/For.php';

if (\false) {
    class ForTokenParser extends \Twig_TokenParser_For
    {
    }
}
