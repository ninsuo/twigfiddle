<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Block.php';

if (\false) {
    class BlockTokenParser extends \Twig_TokenParser_Block
    {
    }
}
