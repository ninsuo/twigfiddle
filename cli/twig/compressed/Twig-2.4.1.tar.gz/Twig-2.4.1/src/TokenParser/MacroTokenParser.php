<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Macro.php';

if (\false) {
    class MacroTokenParser extends \Twig_TokenParser_Macro
    {
    }
}
