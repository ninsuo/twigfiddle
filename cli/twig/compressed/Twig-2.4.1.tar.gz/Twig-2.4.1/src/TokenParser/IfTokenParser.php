<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/If.php';

if (\false) {
    class IfTokenParser extends \Twig_TokenParser_If
    {
    }
}
