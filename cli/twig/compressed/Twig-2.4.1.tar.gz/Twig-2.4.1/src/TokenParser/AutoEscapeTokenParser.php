<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/AutoEscape.php';

if (\false) {
    class AutoEscapeTokenParser extends \Twig_TokenParser_AutoEscape
    {
    }
}
