<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Sandbox.php';

if (\false) {
    class SandboxNode extends \Twig_Node_Sandbox
    {
    }
}
