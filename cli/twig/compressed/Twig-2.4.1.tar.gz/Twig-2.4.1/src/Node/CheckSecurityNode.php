<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/CheckSecurity.php';

if (\false) {
    class CheckSecurityNode extends \Twig_Node_CheckSecurity
    {
    }
}
