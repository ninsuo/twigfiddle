<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Array.php';

if (\false) {
    class ArrayExpression extends \Twig_Node_Expression_Array
    {
    }
}
