<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/StartsWith.php';

if (\false) {
    class StartsWithBinary extends \Twig_Node_Expression_Binary_StartsWith
    {
    }
}
