<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Constant.php';

if (\false) {
    class ConstantExpression extends \Twig_Node_Expression_Constant
    {
    }
}
