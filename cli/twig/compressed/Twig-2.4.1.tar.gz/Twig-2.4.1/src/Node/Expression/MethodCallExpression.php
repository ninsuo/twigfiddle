<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/MethodCall.php';

if (\false) {
    class MethodCallExpression extends \Twig_Node_Expression_MethodCall
    {
    }
}
