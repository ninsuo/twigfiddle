<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Parent.php';

if (\false) {
    class ParentExpression extends \Twig_Node_Expression_Parent
    {
    }
}
