<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/TempName.php';

if (\false) {
    class TempNameExpression extends \Twig_Node_Expression_TempName
    {
    }
}
