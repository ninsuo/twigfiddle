<?php

namespace Twig\Node\Expression\Filter;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Filter/Default.php';

if (\false) {
    class DefaultFilter extends \Twig_Node_Expression_Filter_Default
    {
    }
}
