<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/BitwiseAnd.php';

if (\false) {
    class BitwiseAndBinary extends \Twig_Node_Expression_Binary_BitwiseAnd
    {
    }
}
