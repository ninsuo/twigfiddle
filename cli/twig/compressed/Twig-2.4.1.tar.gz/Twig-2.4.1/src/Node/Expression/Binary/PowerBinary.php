<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Power.php';

if (\false) {
    class PowerBinary extends \Twig_Node_Expression_Binary_Power
    {
    }
}
