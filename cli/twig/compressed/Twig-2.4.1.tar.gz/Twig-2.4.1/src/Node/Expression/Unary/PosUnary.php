<?php

namespace Twig\Node\Expression\Unary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Unary/Pos.php';

if (\false) {
    class PosUnary extends \Twig_Node_Expression_Unary_Pos
    {
    }
}
