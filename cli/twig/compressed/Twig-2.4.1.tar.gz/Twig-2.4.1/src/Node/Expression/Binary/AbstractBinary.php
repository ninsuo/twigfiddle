<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary.php';

if (\false) {
    class AbstractBinary extends \Twig_Node_Expression_Binary
    {
    }
}
