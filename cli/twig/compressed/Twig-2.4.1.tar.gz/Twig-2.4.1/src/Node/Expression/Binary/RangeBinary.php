<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Range.php';

if (\false) {
    class RangeBinary extends \Twig_Node_Expression_Binary_Range
    {
    }
}
