<?php

namespace Twig;

require __DIR__.'/../lib/Twig/TemplateWrapper.php';

if (\false) {
    class TemplateWrapper extends \Twig_TemplateWrapper
    {
    }
}
