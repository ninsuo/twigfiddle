<?php

namespace Twig\Profiler\Node;

require __DIR__.'/../../../lib/Twig/Profiler/Node/EnterProfile.php';

if (\false) {
    class EnterProfileNode extends \Twig_Profiler_Node_EnterProfile
    {
    }
}
