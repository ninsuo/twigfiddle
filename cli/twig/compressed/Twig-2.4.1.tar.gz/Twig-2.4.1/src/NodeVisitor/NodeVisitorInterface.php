<?php

namespace Twig\NodeVisitor;

require __DIR__.'/../../lib/Twig/NodeVisitorInterface.php';

if (\false) {
    interface NodeVisitorInterface extends \Twig_NodeVisitorInterface
    {
    }
}
