<?php

namespace Twig\NodeVisitor;

require __DIR__.'/../../lib/Twig/NodeVisitor/Escaper.php';

if (\false) {
    class EscaperNodeVisitor extends \Twig_NodeVisitor_Escaper
    {
    }
}
