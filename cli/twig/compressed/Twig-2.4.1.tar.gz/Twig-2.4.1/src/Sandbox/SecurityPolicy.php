<?php

namespace Twig\Sandbox;

require __DIR__.'/../../lib/Twig/Sandbox/SecurityPolicy.php';

if (\false) {
    class SecurityPolicy extends \Twig_Sandbox_SecurityPolicy
    {
    }
}
