<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Markup.php';

if (\false) {
    class Markup extends \Twig_Markup
    {
    }
}
