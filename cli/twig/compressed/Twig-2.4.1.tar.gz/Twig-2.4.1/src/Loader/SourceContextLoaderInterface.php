<?php

namespace Twig\Loader;

require __DIR__.'/../../lib/Twig/SourceContextLoaderInterface.php';

if (\false) {
    interface SourceContextLoaderInterface extends \Twig_SourceContextLoaderInterface
    {
    }
}
