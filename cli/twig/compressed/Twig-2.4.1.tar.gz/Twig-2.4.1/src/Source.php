<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Source.php';

if (\false) {
    class Source extends \Twig_Source
    {
    }
}
