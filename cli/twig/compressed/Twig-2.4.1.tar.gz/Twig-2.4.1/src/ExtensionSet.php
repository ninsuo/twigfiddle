<?php

namespace Twig;

require __DIR__.'/../lib/Twig/ExtensionSet.php';

if (\false) {
    class ExtensionSet extends \Twig_ExtensionSet
    {
    }
}
