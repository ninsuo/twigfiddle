<?php

namespace Twig\Error;

require __DIR__.'/../../lib/Twig/Error/Loader.php';

if (\false) {
    class LoaderError extends \Twig_Error_Loader
    {
    }
}
