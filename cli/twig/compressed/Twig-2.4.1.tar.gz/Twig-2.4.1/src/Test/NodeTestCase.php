<?php

namespace Twig\Test;

require __DIR__.'/../../lib/Twig/Test/NodeTestCase.php';

if (\false) {
    class NodeTestCase extends \Twig_Test_NodeTestCase
    {
    }
}
