<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/ExtensionInterface.php';

if (\false) {
    interface ExtensionInterface extends \Twig_ExtensionInterface
    {
    }
}
