<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/Sandbox.php';

if (\false) {
    class SandboxExtension extends \Twig_Extension_Sandbox
    {
    }
}
