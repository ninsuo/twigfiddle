<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/InitRuntimeInterface.php';

if (\false) {
    interface InitRuntimeInterface extends \Twig_Extension_InitRuntimeInterface
    {
    }
}
