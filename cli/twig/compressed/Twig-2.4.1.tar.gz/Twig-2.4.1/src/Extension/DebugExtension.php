<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/Debug.php';

if (\false) {
    class DebugExtension extends \Twig_Extension_Debug
    {
    }
}
