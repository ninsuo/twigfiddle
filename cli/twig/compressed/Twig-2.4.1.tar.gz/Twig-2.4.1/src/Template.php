<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Template.php';

if (\false) {
    class Template extends \Twig_Template
    {
    }
}
