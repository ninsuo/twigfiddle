<?php

namespace Twig\Node;

class_exists('Twig_Node_Print');

if (\false) {
    class PrintNode extends \Twig_Node_Print
    {
    }
}
