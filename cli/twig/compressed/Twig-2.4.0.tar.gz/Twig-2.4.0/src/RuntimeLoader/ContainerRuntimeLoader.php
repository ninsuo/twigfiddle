<?php

namespace Twig\RuntimeLoader;

require __DIR__.'/../../lib/Twig/ContainerRuntimeLoader.php';

if (\false) {
    class ContainerRuntimeLoader extends \Twig_ContainerRuntimeLoader
    {
    }
}
