<?php

namespace Twig\Test;

require __DIR__.'/../../lib/Twig/Test/IntegrationTestCase.php';

if (\false) {
    class IntegrationTestCase extends \Twig_Test_IntegrationTestCase
    {
    }
}
