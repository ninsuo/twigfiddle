<?php

namespace Twig\Loader;

require __DIR__.'/../../lib/Twig/Loader/Array.php';

if (\false) {
    class ArrayLoader extends \Twig_Loader_Array
    {
    }
}
