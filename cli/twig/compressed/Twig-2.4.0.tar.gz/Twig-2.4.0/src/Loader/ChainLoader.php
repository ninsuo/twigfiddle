<?php

namespace Twig\Loader;

require __DIR__.'/../../lib/Twig/Loader/Chain.php';

if (\false) {
    class ChainLoader extends \Twig_Loader_Chain
    {
    }
}
