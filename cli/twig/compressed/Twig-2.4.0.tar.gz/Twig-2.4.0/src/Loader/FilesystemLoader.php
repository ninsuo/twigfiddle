<?php

namespace Twig\Loader;

require __DIR__.'/../../lib/Twig/Loader/Filesystem.php';

if (\false) {
    class FilesystemLoader extends \Twig_Loader_Filesystem
    {
    }
}
