<?php

namespace Twig\Loader;

require __DIR__.'/../../lib/Twig/ExistsLoaderInterface.php';

if (\false) {
    interface ExistsLoaderInterface extends \Twig_ExistsLoaderInterface
    {
    }
}
