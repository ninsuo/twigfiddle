<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/Extends.php';

if (\false) {
    class ExtendsTokenParser extends \Twig_TokenParser_Extends
    {
    }
}
