<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParserInterface.php';

if (\false) {
    interface TokenParserInterface extends \Twig_TokenParserInterface
    {
    }
}
