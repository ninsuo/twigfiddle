<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/With.php';

if (\false) {
    class WithTokenParser extends \Twig_TokenParser_With
    {
    }
}
