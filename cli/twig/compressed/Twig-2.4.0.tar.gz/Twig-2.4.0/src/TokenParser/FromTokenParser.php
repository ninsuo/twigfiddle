<?php

namespace Twig\TokenParser;

require __DIR__.'/../../lib/Twig/TokenParser/From.php';

if (\false) {
    class FromTokenParser extends \Twig_TokenParser_From
    {
    }
}
