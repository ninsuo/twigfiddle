<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Compiler.php';

if (\false) {
    class Compiler extends \Twig_Compiler
    {
    }
}
