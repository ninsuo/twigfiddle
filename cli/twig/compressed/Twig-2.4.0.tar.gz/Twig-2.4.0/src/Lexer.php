<?php

namespace Twig;

require __DIR__.'/../lib/Twig/Lexer.php';

if (\false) {
    class Lexer extends \Twig_Lexer
    {
    }
}
