<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/SetTemp.php';

if (\false) {
    class SetTempNode extends \Twig_Node_SetTemp
    {
    }
}
