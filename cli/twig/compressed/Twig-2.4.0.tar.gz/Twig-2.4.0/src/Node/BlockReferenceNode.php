<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/BlockReference.php';

if (\false) {
    class BlockReferenceNode extends \Twig_Node_BlockReference
    {
    }
}
