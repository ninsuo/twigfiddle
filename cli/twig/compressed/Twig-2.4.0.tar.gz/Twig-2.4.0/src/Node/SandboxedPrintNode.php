<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/SandboxedPrint.php';

if (\false) {
    class SandboxedPrintNode extends \Twig_Node_SandboxedPrint
    {
    }
}
