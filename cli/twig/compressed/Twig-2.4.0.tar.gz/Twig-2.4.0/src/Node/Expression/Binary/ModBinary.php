<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Mod.php';

if (\false) {
    class ModBinary extends \Twig_Node_Expression_Binary_Mod
    {
    }
}
