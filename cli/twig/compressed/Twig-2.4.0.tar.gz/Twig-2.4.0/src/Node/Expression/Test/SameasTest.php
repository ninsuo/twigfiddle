<?php

namespace Twig\Node\Expression\Test;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Test/Sameas.php';

if (\false) {
    class SameasTest extends \Twig_Node_Expression_Test_Sameas
    {
    }
}
