<?php

namespace Twig\Node\Expression\Test;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Test/Null.php';

if (\false) {
    class NullTest extends \Twig_Node_Expression_Test_Null
    {
    }
}
