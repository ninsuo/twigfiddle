<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/BitwiseXor.php';

if (\false) {
    class BitwiseXorBinary extends \Twig_Node_Expression_Binary_BitwiseXor
    {
    }
}
