<?php

namespace Twig\Node\Expression\Binary;

require __DIR__.'/../../../../lib/Twig/Node/Expression/Binary/Matches.php';

if (\false) {
    class MatchesBinary extends \Twig_Node_Expression_Binary_Matches
    {
    }
}
