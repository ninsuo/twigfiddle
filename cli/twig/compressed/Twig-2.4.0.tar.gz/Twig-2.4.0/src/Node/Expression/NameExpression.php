<?php

namespace Twig\Node\Expression;

require __DIR__.'/../../../lib/Twig/Node/Expression/Name.php';

if (\false) {
    class NameExpression extends \Twig_Node_Expression_Name
    {
    }
}
