<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/AutoEscape.php';

if (\false) {
    class AutoEscapeNode extends \Twig_Node_AutoEscape
    {
    }
}
