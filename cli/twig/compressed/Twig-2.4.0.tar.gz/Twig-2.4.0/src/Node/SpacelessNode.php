<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Spaceless.php';

if (\false) {
    class SpacelessNode extends \Twig_Node_Spaceless
    {
    }
}
