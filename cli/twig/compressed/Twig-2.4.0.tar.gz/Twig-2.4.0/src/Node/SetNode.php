<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Set.php';

if (\false) {
    class SetNode extends \Twig_Node_Set
    {
    }
}
