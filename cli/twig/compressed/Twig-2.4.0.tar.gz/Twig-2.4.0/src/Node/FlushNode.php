<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Flush.php';

if (\false) {
    class FlushNode extends \Twig_Node_Flush
    {
    }
}
