<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Module.php';

if (\false) {
    class ModuleNode extends \Twig_Node_Module
    {
    }
}
