<?php

namespace Twig\Node;

require __DIR__.'/../../lib/Twig/Node/Text.php';

if (\false) {
    class TextNode extends \Twig_Node_Text
    {
    }
}
