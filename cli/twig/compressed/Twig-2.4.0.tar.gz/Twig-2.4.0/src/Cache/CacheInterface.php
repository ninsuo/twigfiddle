<?php

namespace Twig\Cache;

require __DIR__.'/../../lib/Twig/CacheInterface.php';

if (\false) {
    interface CacheInterface extends \Twig_CacheInterface
    {
    }
}
