<?php

namespace Twig\Cache;

require __DIR__.'/../../lib/Twig/Cache/Null.php';

if (\false) {
    class NullCache extends \Twig_Cache_Null
    {
    }
}
