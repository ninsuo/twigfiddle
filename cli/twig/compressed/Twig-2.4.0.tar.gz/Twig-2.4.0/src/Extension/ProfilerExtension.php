<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/Profiler.php';

if (\false) {
    class ProfilerExtension extends \Twig_Extension_Profiler
    {
    }
}
