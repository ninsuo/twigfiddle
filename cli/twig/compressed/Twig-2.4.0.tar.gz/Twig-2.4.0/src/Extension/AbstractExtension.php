<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension.php';

if (\false) {
    class AbstractExtension extends \Twig_Extension
    {
    }
}
