<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/Staging.php';

if (\false) {
    class StagingExtension extends \Twig_Extension_Staging
    {
    }
}
