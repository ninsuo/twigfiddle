<?php

namespace Twig\Extension;

require __DIR__.'/../../lib/Twig/Extension/StringLoader.php';

if (\false) {
    class StringLoaderExtension extends \Twig_Extension_StringLoader
    {
    }
}
