<?php

namespace Twig;

require __DIR__.'/../lib/Twig/ExpressionParser.php';

if (\false) {
    class ExpressionParser extends \Twig_ExpressionParser
    {
    }
}
