<?php

namespace Twig\Profiler\Dumper;

require __DIR__.'/../../../lib/Twig/Profiler/Dumper/Html.php';

if (\false) {
    class HtmlDumper extends \Twig_Profiler_Dumper_Html
    {
    }
}
