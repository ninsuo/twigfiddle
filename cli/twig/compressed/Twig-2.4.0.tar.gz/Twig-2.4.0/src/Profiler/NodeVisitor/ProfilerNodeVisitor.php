<?php

namespace Twig\Profiler\NodeVisitor;

require __DIR__.'/../../../lib/Twig/Profiler/NodeVisitor/Profiler.php';

if (\false) {
    class ProfilerNodeVisitor extends \Twig_Profiler_NodeVisitor_Profiler
    {
    }
}
