Filters
=======

.. toctree::
    :maxdepth: 1

    date
    date_modify
    format
    replace
    number_format
    url_encode
    json_encode
    convert_encoding
    title
    capitalize
    nl2br
    upper
    lower
    striptags
    join
    split
    reverse
    abs
    length
    sort
    default
    keys
    escape
    raw
    merge
    slice
    first
    last
    trim
