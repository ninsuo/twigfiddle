<?php

namespace Twig\Test;

class_exists('Twig_Test_IntegrationTestCase');

if (\false) {
    class IntegrationTestCase extends \Twig_Test_IntegrationTestCase
    {
    }
}
