<?php

namespace Twig;

class_exists('Twig_SimpleFilter');

if (\false) {
    class TwigFilter extends \Twig_SimpleFilter
    {
    }
}
