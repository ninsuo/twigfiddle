<?php

namespace Twig\Extension;

class_exists('Twig_Extension_Staging');

if (\false) {
    class StagingExtension extends \Twig_Extension_Staging
    {
    }
}
