Tests
=====

.. toctree::
    :maxdepth: 1

    divisibleby
    null
    even
    odd
    sameas
    constant
    defined
    empty
