<?php

namespace Twig\Profiler\Dumper;

class_exists('Twig_Profiler_Dumper_Blackfire');

if (\false) {
    class BlackfireDumper extends \Twig_Profiler_Dumper_Blackfire
    {
    }
}
