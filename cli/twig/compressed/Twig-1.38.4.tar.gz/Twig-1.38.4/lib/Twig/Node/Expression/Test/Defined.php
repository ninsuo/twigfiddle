<?php

use Twig\Node\Expression\Test\DefinedTest;

class_exists('Twig\Node\Expression\Test\DefinedTest');

if (\false) {
    class Twig_Node_Expression_Test_Defined extends DefinedTest
    {
    }
}
