<?php

use Twig\Loader\ExistsLoaderInterface;

class_exists('Twig\Loader\ExistsLoaderInterface');

if (\false) {
    class Twig_ExistsLoaderInterface extends ExistsLoaderInterface
    {
    }
}
