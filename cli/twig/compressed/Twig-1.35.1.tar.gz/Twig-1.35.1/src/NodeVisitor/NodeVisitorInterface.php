<?php

namespace Twig\NodeVisitor;

class_exists('Twig_NodeVisitorInterface');

if (\false) {
    interface NodeVisitorInterface extends \Twig_NodeVisitorInterface
    {
    }
}
