The Text Extension
==================

The Text extensions provides the following filters:

* ``truncate``
* ``wordwrap``
* ``nl2br``
