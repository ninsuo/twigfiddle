<?php

namespace Twig\Extensions;

class_exists('Twig_Extensions_Extension_Intl');

if (\false) {
    class IntlExtension extends \Twig_Extensions_Extension_Intl
    {
    }
}
