The Text Extension
==================

The Text extension provides the following filters:

* ``truncate``
* ``wordwrap``
* ``nl2br``
