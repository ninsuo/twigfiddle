The Array Extension
===================

The Array extensions provides the following filters:

* ``shuffle``
