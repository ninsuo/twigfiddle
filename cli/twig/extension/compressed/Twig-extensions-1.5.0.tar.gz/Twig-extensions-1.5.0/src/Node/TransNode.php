<?php

namespace Twig\Extensions\Node;

require __DIR__.'/../../lib/Twig/Extensions/Node/Trans.php';

if (\false) {
    class TransNode extends \Twig_Extensions_Node_Trans
    {
    }
}
