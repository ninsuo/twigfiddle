<?php

namespace Twig\Extensions;

require __DIR__.'/../lib/Twig/Extensions/Extension/Date.php';

if (\false) {
    class DateExtension extends \Twig_Extensions_Extension_Date
    {
    }
}
