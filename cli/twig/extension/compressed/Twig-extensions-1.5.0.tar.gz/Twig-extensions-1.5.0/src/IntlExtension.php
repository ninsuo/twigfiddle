<?php

namespace Twig\Extensions;

require __DIR__.'/../lib/Twig/Extensions/Extension/Intl.php';

if (\false) {
    class IntlExtension extends \Twig_Extensions_Extension_Intl
    {
    }
}
