<?php

namespace Twig\Extensions;

require __DIR__.'/../lib/Twig/Extensions/Extension/Array.php';

if (\false) {
    class ArrayExtension extends \Twig_Extensions_Extension_Array
    {
    }
}
