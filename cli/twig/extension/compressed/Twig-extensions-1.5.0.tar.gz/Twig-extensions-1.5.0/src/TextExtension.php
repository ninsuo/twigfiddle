<?php

namespace Twig\Extensions;

require __DIR__.'/../lib/Twig/Extensions/Extension/Text.php';

if (\false) {
    class TextExtension extends \Twig_Extensions_Extension_Text
    {
    }
}
