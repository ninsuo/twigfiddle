<?php

namespace Twig\Extensions;

require __DIR__.'/../lib/Twig/Extensions/Extension/I18n.php';

if (\false) {
    class I18nExtension extends \Twig_Extensions_Extension_I18n
    {
    }
}
