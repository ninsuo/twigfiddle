<?php

namespace Twig\Extensions\TokenParser;

require __DIR__.'/../../lib/Twig/Extensions/TokenParser/Trans.php';

if (\false) {
    class TransTokenParser extends \Twig_Extensions_TokenParser_Trans
    {
    }
}
