<?php

namespace Twig\Extensions\Node;

class_exists('Twig_Extensions_Node_Trans');

if (\false) {
    class TransNode extends \Twig_Extensions_Node_Trans
    {
    }
}
